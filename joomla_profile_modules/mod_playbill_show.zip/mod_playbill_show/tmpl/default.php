<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;

$app = Factory::getApplication();
$input = $app->input;

$module_show_id = $params->get('show_id', 0);
$url_show_id = $input->getInt('show_id', 0);

if (!empty($module_show_id) && $module_show_id > 0) {
    $show_id = $module_show_id;
} elseif (!empty($url_show_id) && $url_show_id > 0) {
    $show_id = $url_show_id;
} else {
    $show_id = 0;
}

echo '<!-- Playbill Show Profile Module START: Module Show ID = ' . htmlspecialchars($module_show_id) . ', URL Show ID = ' . htmlspecialchars($url_show_id) . ', Final Show ID = ' . htmlspecialchars($show_id) . ' -->';

$api_base_url = $params->get('api_base_url', 'https://www.broadwayandmain.com/playbill_app/api/joomla');
$public_base_url = $params->get('public_base_url', 'https://www.broadwayandmain.com/playbill_app/public');
$profile_base_url = $params->get('profile_base_url', $public_base_url);
$actor_profile_url = $params->get('actor_profile_url', '');
$module_enabled = $params->get('module_enabled', 1);

if (empty($actor_profile_url)) {
    $actor_profile_url = !empty($profile_base_url) ? $profile_base_url : $public_base_url;
}

if (!$module_enabled) {
    echo '<!-- Playbill Show Module: Module is disabled -->';
    return;
}

if (empty($show_id) || $show_id == 0) {
    echo '<div class="playbill-error" style="padding: 15px; background: #fee; border: 2px solid #fcc; color: #c00; border-radius: 4px; margin: 10px 0;">';
    echo '<strong>Playbill Show Module Error</strong><br>';
    echo 'Show ID is missing or invalid. Please set a valid Show ID in the module parameters.';
    echo '<br><small>Current Show ID: ' . htmlspecialchars($show_id) . '</small>';
    echo '</div>';
    return;
}

$show_data = ModPlaybillShowHelper::getShowData($show_id, $api_base_url, $public_base_url);

if (!$show_data) {
    echo '<div class="playbill-error" style="padding: 15px; background: #fee; border: 2px solid #fcc; color: #c00; border-radius: 4px; margin: 10px 0;">';
    echo '<strong>Playbill Show Module Error</strong><br>';
    echo 'Show not found or error loading data for Show ID: <strong>' . htmlspecialchars($show_id) . '</strong><br>';
    echo 'Please verify:<br>';
    echo '1. The Show ID exists in the Playbill database<br>';
    echo '2. The API endpoint is accessible: <code>' . htmlspecialchars($api_base_url . '/show/' . $show_id) . '</code><br>';
    echo '3. Check Joomla error logs for detailed error messages';
    if (Factory::getApplication()->get('debug')) {
        echo '<br><br><strong>Debug Info:</strong><br>';
        echo 'API Base URL: ' . htmlspecialchars($api_base_url) . '<br>';
        echo 'Full API URL: ' . htmlspecialchars($api_base_url . '/show/' . $show_id) . '<br>';
    }
    echo '</div>';
    return;
}

if (empty($show_data['productions'])) {
    echo '<div class="playbill-show-module" style="margin: 20px 0; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff;">';
    echo '<h2 class="playbill-title" style="font-size: 28px; font-weight: bold; margin-bottom: 15px; color: #1f2937;">';
    echo htmlspecialchars($show_data['title']);
    echo '</h2>';
    echo '<p style="color: #6b7280; padding: 20px; text-align: center;">No productions found for this show.</p>';
    echo '</div>';
    return;
}

$latest_production = $show_data['productions'][0];
$credits_by_category = ModPlaybillShowHelper::groupCreditsByCategory($latest_production['credits']);

$all_credits = [];
if (!empty($latest_production['credits']) && is_array($latest_production['credits'])) {
    $all_credits = $latest_production['credits'];
    usort($all_credits, function($a, $b) {
        $nameA = isset($a['person']['name']) ? strtolower($a['person']['name']) : '';
        $nameB = isset($b['person']['name']) ? strtolower($b['person']['name']) : '';
        return strcmp($nameA, $nameB);
    });
}

?>
<div class="playbill-show-module" style="margin: 20px 0; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; background: #fff;">
    <h2 class="playbill-title" style="font-size: 28px; font-weight: bold; margin-bottom: 15px; color: #1f2937;">
        <?php echo htmlspecialchars($show_data['title']); ?>
    </h2>
    
    <div style="margin-bottom: 20px; padding: 15px; background: #f9fafb; border-radius: 6px; border-left: 4px solid #4f46e5;">
        <p style="margin: 0; color: #6b7280; font-size: 16px;">
            <strong style="color: #1f2937;">Theater:</strong> 
            <?php echo htmlspecialchars($latest_production['theater']['name']); ?>
        </p>
        <p style="margin: 5px 0 0 0; color: #6b7280; font-size: 16px;">
            <strong style="color: #1f2937;">Year:</strong> 
            <?php echo (int)$latest_production['year']; ?>
        </p>
    </div>
    
    <?php if (!empty($credits_by_category) || !empty($all_credits)): ?>
    <div style="margin-bottom: 20px; border-bottom: 2px solid #e5e7eb;">
        <button onclick="showView('category')" id="view-category-btn" style="padding: 10px 20px; margin-right: 10px; background: #4f46e5; color: white; border: none; border-radius: 6px 6px 0 0; cursor: pointer; font-weight: 600; font-size: 14px;">By Category</button>
        <button onclick="showView('alphabetical')" id="view-alphabetical-btn" style="padding: 10px 20px; background: #e5e7eb; color: #6b7280; border: none; border-radius: 6px 6px 0 0; cursor: pointer; font-weight: 600; font-size: 14px;">Alphabetical</button>
    </div>
    
    <div id="category-view">
    <?php if (!empty($credits_by_category)): ?>
    <?php foreach ($credits_by_category as $category => $credits): ?>
    <div class="playbill-category" style="margin-bottom: 30px;">
        <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 15px; color: #4b5563; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px;">
            <?php echo htmlspecialchars($category); ?>
        </h3>
        <ul style="list-style: none; padding: 0; margin: 0;">
            <?php foreach ($credits as $credit): ?>
            <li style="padding: 10px 0; border-bottom: 1px solid #f3f4f6;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong style="font-size: 16px; color: #1f2937;">
                            <?php 
                            $person_url = '';
                            if (strpos($actor_profile_url, 'index.php') !== false) {
                                if (strpos($actor_profile_url, '?') !== false) {
                                    $person_url = $actor_profile_url . '&id=' . $credit['person']['id'] . '&type=actor';
                                } else {
                                    $person_url = $actor_profile_url . '?id=' . $credit['person']['id'] . '&type=actor';
                                }
                            } else {
                                $person_url = rtrim($actor_profile_url, '/') . '/actor/' . $credit['person']['id'];
                            }
                            ?>
                            <a href="<?php echo htmlspecialchars($person_url); ?>" style="color: #4f46e5; text-decoration: none;">
                                <?php echo htmlspecialchars($credit['person']['name']); ?>
                            </a>
                        </strong>
                        <?php if (!empty($credit['role']) && $credit['role'] !== $category): ?>
                            <span style="color: #6b7280; margin-left: 8px;">as <?php echo htmlspecialchars($credit['role']); ?></span>
                        <?php endif; ?>
                        <?php if ($credit['is_equity']): ?>
                            <span style="color: #10b981; font-weight: 600; margin-left: 5px;">*</span>
                        <?php endif; ?>
                    </div>
                </div>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
    </div>
    
    <div id="alphabetical-view" style="display: none;">
    <?php if (!empty($all_credits)): ?>
    <ul style="list-style: none; padding: 0; margin: 0;">
        <?php foreach ($all_credits as $credit): ?>
        <li style="padding: 10px 0; border-bottom: 1px solid #f3f4f6;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <strong style="font-size: 16px; color: #1f2937;">
                        <?php 
                        $person_url = '';
                        if (strpos($actor_profile_url, 'index.php') !== false) {
                            if (strpos($actor_profile_url, '?') !== false) {
                                $person_url = $actor_profile_url . '&id=' . $credit['person']['id'] . '&type=actor';
                            } else {
                                $person_url = $actor_profile_url . '?id=' . $credit['person']['id'] . '&type=actor';
                            }
                        } else {
                            $person_url = rtrim($actor_profile_url, '/') . '/actor/' . $credit['person']['id'];
                        }
                        ?>
                        <a href="<?php echo htmlspecialchars($person_url); ?>" style="color: #4f46e5; text-decoration: none;">
                            <?php echo htmlspecialchars($credit['person']['name']); ?>
                        </a>
                    </strong>
                    <?php if (!empty($credit['role'])): ?>
                        <span style="color: #6b7280; margin-left: 8px;">- <?php echo htmlspecialchars($credit['role']); ?></span>
                    <?php endif; ?>
                    <?php if (!empty($credit['category'])): ?>
                        <span style="color: #9ca3af; margin-left: 8px; font-size: 14px;">(<?php echo htmlspecialchars($credit['category']); ?>)</span>
                    <?php endif; ?>
                    <?php if ($credit['is_equity']): ?>
                        <span style="color: #10b981; font-weight: 600; margin-left: 5px;">*</span>
                    <?php endif; ?>
                </div>
            </div>
        </li>
        <?php endforeach; ?>
    </ul>
    <?php else: ?>
    <p style="color: #6b7280; padding: 20px; text-align: center;">No credits found for this production.</p>
    <?php endif; ?>
    </div>
    <?php else: ?>
    <p style="color: #6b7280; padding: 20px; text-align: center;">No credits found for this production.</p>
    <?php endif; ?>
</div>

<script>
function showView(view) {
    const categoryView = document.getElementById('category-view');
    const alphabeticalView = document.getElementById('alphabetical-view');
    const categoryBtn = document.getElementById('view-category-btn');
    const alphabeticalBtn = document.getElementById('view-alphabetical-btn');
    
    if (view === 'category') {
        categoryView.style.display = 'block';
        alphabeticalView.style.display = 'none';
        categoryBtn.style.background = '#4f46e5';
        categoryBtn.style.color = 'white';
        alphabeticalBtn.style.background = '#e5e7eb';
        alphabeticalBtn.style.color = '#6b7280';
    } else {
        categoryView.style.display = 'none';
        alphabeticalView.style.display = 'block';
        categoryBtn.style.background = '#e5e7eb';
        categoryBtn.style.color = '#6b7280';
        alphabeticalBtn.style.background = '#4f46e5';
        alphabeticalBtn.style.color = 'white';
    }
}
</script>
<style>
.playbill-show-module ~ .item-page,
.playbill-show-module ~ article,
.playbill-show-module ~ .item-page,
.playbill-show-module ~ article {
    display: none !important;
}
body.item-view .item-page:has(+ .playbill-show-module),
body.item-view article:has(+ .playbill-show-module) {
    display: none !important;
}
</style>
<script>
(function() {
    document.addEventListener('DOMContentLoaded', function() {
        const moduleContainer = document.querySelector('.playbill-show-module');
        if (moduleContainer) {
            const articleContent = moduleContainer.closest('.item-page') || 
                                 moduleContainer.closest('article') ||
                                 document.querySelector('.item-page') ||
                                 document.querySelector('article');
            if (articleContent && articleContent !== moduleContainer && !articleContent.contains(moduleContainer)) {
                articleContent.style.display = 'none';
            }
            
            const nextSibling = moduleContainer.nextElementSibling;
            if (nextSibling && (nextSibling.classList.contains('item-page') || nextSibling.tagName === 'ARTICLE')) {
                nextSibling.style.display = 'none';
            }
            
            const parent = moduleContainer.parentElement;
            if (parent) {
                const siblings = Array.from(parent.children);
                const moduleIndex = siblings.indexOf(moduleContainer);
                siblings.slice(moduleIndex + 1).forEach(function(sibling) {
                    if (sibling.classList.contains('item-page') || 
                        sibling.classList.contains('article-content') ||
                        sibling.tagName === 'ARTICLE' ||
                        (sibling.classList.contains('content') && !sibling.contains(moduleContainer))) {
                        sibling.style.display = 'none';
                    }
                });
            }
        }
    });
})();
</script>
<!-- Playbill Show Profile Module END -->
